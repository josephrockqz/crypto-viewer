module.exports = {
  devServer: {
    proxy: 'http://backend.test/'
  }
}
